import {
  BrowserRouter as Router,
  Switch,
  Route
} from "react-router-dom";
import Search from "./pages/Search";
import SearchList from './pages/SearchList';
import ViewBasicReport from "./pages/ViewBasicReport";

function App() {
  return (
    <Router>
      <div>     
        <Switch>
          <Route path="/searchList">
            <SearchList />
          </Route>
          <Route path="/viewBasicReport/:fdcId">
            <ViewBasicReport/>
          </Route>
          <Route path="/">
            <Search />
          </Route>
        </Switch>
      </div>
    </Router>
  );
}

export default App;

