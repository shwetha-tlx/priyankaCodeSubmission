import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";

function createData(
  nutrientId,
  derivationCode,
  derivationDescription,
  nutrientName,
  nutrientNumber,
  unitName,
  value
) {
  return {
    nutrientId,
    derivationCode,
    derivationDescription,
    nutrientName,
    nutrientNumber,
    unitName,
    value,
  };
}

const ViewBasicReport = () => {
  let { fdcId } = useParams();
  const getData = () => {
    const data = JSON.parse(localStorage.getItem("searchList"));
    return data.filter((d) => d.fdcId == fdcId);
  };
  const [data, setData] = useState(getData);

  return (
    <>
      {data.length && (
        <>
          <h1>{data[0].description}</h1>
          <TableContainer component={Paper}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell>Derivation Code</TableCell>
                  <TableCell align="right">Derivation Description</TableCell>
                  <TableCell align="right">Nutrition Name</TableCell>
                  <TableCell align="right">Nutrition Number</TableCell>
                  <TableCell align="right">Unit Name</TableCell>
                  <TableCell align="right">Value</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {data[0]?.foodNutrients.map((row, index) => (
                  <TableRow
                    key={index}
                    sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                  >
                    <TableCell component="th" scope="row">
                      {row.derivationCode}
                    </TableCell>
                    <TableCell align="right">
                      {row.derivationDescription}
                    </TableCell>
                    <TableCell align="right">{row.nutrientName}</TableCell>
                    <TableCell align="right">{row.nutrientNumber}</TableCell>
                    <TableCell align="right">{row.unitName}</TableCell>
                    <TableCell align="right">{row.value}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </>
      )}
    </>
  );
};

export default ViewBasicReport;
