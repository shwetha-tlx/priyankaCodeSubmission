import { useState } from "react";
import { useHistory } from "react-router-dom";
import axios from "axios";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import Grid from "@mui/material/Grid";
import { API_KEY } from "../utility/Constants";

const Search = () => {
  const history = useHistory();
  const [searchText, setSearchText] = useState();

  const handleSearchText = (e) => {
    setSearchText(e.target.value);
  };

  const handleSearch = () => {
    axios
      .get(`https://api.nal.usda.gov/fdc/v1/foods/search`, {
        params: {
          query: searchText,
          api_key: API_KEY,
        },
      })
      .then((res) => {
        localStorage.setItem("searchList", JSON.stringify(res?.data?.foods));
        history.push("/searchList");
      })
      .catch((error) => {
        console.log(error);
      });
  };
  return (
    <Box component="form" noValidate autoComplete="off">
      <h1>FoodData Central</h1>
      <p>Search FoodData Central:</p>
      <Grid container spacing={3}>
        <Grid item xs="auto">
          <TextField
            label="Search Food"
            variant="outlined"
            onInput={handleSearchText}
          />
        </Grid>
        <Grid item xs="auto">
          <Button
            variant="contained"
            disabled={searchText ? false : true}
            onClick={handleSearch}
          >
            Search
          </Button>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Search;
