import { useState, useEffect } from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { Link } from "react-router-dom";

function createData(number, description, date, category) {
  return { number, description, date, category };
}

const getData = () => {
  const data = JSON.parse(localStorage.getItem("searchList"));
  return data.reduce((acc, curr) => {
    acc.push(
      createData(
        curr.fdcId,
        curr.description,
        curr.publishedDate,
        curr.foodCategory
      )
    );
    return acc;
  }, []);
};

const SearchList = () => {
  const [foodList, setFoodList] = useState(getData);
  return (
    <>
      <h1>FoodData Central Search Results</h1>
      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 650 }} aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell>NDB Number</TableCell>
              <TableCell align="right">Description</TableCell>
              <TableCell align="right">Most Recent Acquisition Date</TableCell>
              <TableCell align="right">SR Food Category</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {foodList.map((row) => (
              <TableRow
                key={row.number}
                sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
              >
                <TableCell component="th" scope="row">
                  {row.number}
                </TableCell>
                <TableCell align="right">
                  <Link
                    to={{
                      pathname: "/viewBasicReport/" + row.number,
                      state: { data: getData() },
                    }}
                  >
                    {row.description}
                  </Link>
                </TableCell>
                <TableCell align="right">{row.date}</TableCell>
                <TableCell align="right">{row.category}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </>
  );
};

export default SearchList;
